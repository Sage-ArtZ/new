<?php
  include "conn.php";
  if(isset($_POST['submit'])) {
    $product_name = $_POST['product'];
    $simple = $_POST['simple'];
    $medium = $_POST['medium'];
    $complex=$_POST['complex'];
    $super_complex = $_POST["super_complex"];
    $sql = "INSERT INTO `safal` (`product_name`, `simple`, `medium`, `complex`, `super_complex`) VALUES ('$product_name','$simple','$medium','$complex','$super_complex')";
    mysqli_query($conn, $sql);

  }
?>

<!DOCTYPE html>
<head><link rel="stylesheet" href="index.css"></head>
<div class="center">
    <h1>Safal Estimation</h1>
    <form method="post">
      <div class="inputbox">
        <input name="product" type="text" required="required">
        <span>Product</span>
      </div>
      <div class="inputbox">
        <input name="simple" type="text" required="required">
        <span>Simple</span>
      </div>
      <div class="inputbox">
        <input name="medium" type="text" required="required">
        <span>Medium</span>
      </div>
      <div class="inputbox">
        <input name="complex" type="text" required="required">
        <span>Complex</span>
      </div>
      <div class="inputbox">
        <input name="super_complex" type="text" required="required">
        <span>Super Complex</span>
      </div>
      <div class="inputbox">
        <button type="submit" name="submit" value="submit">Submit</button>
      </div>
    </form>
  </div>