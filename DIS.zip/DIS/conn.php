<?php 
$conn = mysqli_connect("localhost","root","","sage");
 
if(!$conn){
	die("Connection error: " . mysqli_connect_error());	
}
?>