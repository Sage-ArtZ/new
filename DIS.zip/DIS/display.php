<?php
include 'conn.php';
$query = $conn->query("SELECT * FROM `safal` ");
$fetch = $query->fetch_array();
?>

<html>
    <head>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.5.6/angular.min.js"></script>
    </head>
    <body ng-app="">
        <select value="">choose an option
        <?php 
            while($fetch = $query->fetch_array())
            {
                ?>
                <option value=""><?php echo $fetch['product_name']?></option>
                <?php
            }
        ?>
        </select>
        <?php echo $fetch['product_name']?>
        Simple: <input type="number" ng-model="simple" name="simple"><br>
        {{simple}}<?php echo $fetch['simple']?>

    </body>
</html>